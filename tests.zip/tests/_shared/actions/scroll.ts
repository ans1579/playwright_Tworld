// tests/_shared/actions/scroll.ts
import type { Browser } from 'webdriverio';
import { swipeByPercent, swipeToScroll } from '../gestures/ios';
import { find } from './ui';

type SwipePct = {
    from: { xPct: number; yPct: number };
    to: { xPct: number; yPct: number };
    durationMs?: number;
};

export type ScrollOpts = {
    movePx?: number;
    swipe?: SwipePct;
    settleMs?: number;
};

async function getY(driver: Browser, xpath: string): Promise<number | null> {
    try {
        const el = await find(driver, xpath);
        const y = await el.getLocation('y');
        return typeof y === 'number' ? y : null;
    } catch {
        return null;
    }
}

export async function attemptScrollMove(
    driver: Browser,
    probeXPath: string,
    opts?: ScrollOpts
): Promise<{ moved: boolean; yBefore: number | null; yAfter: number | null }> {
    const movePx = opts?.movePx ?? 6;
    const settleMs = opts?.settleMs ?? 250;

    const yBefore = await getY(driver, probeXPath);

    const swipe = opts?.swipe ?? {
        from: { xPct: 0.5, yPct: 0.78 },
        to: { xPct: 0.5, yPct: 0.35 },
        durationMs: 420,
    };

    await swipeByPercent(driver, swipe.from, swipe.to, { durationMs: swipe.durationMs ?? 420 });
    await driver.pause(settleMs);

    const yAfter = await getY(driver, probeXPath);

    if (yBefore == null || yAfter == null) {
        return { moved: false, yBefore, yAfter };
    }

    const moved = Math.abs(yAfter - yBefore) >= movePx;
    return { moved, yBefore, yAfter };
}

export async function assertScrollable(
    driver: Browser,
    probeXPath: string,
    opts?: ScrollOpts
) {
    const r = await attemptScrollMove(driver, probeXPath, opts);
    if (!r.moved) {
        throw new Error(`스크롤이 필요하지만 실패하였음. yBefore=${r.yBefore} | yAfter=${r.yAfter}`);
    }
    return r;
}

export async function assertNotScrollable(
    driver: Browser,
    probeXPath: string,
    opts?: ScrollOpts
) {
    const r = await attemptScrollMove(driver, probeXPath, opts);
    if (r.moved) {
        throw new Error(`스크롤이 필요하지않지만 스크롤됨. yBefore=${r.yBefore} | yAfter=${r.yAfter}`);
    }
    return r;
}

export async function swipeUp(
    driver: Browser,
    opts?: { durationMs?: number; settleMs?: number }
) {
    await swipeToScroll(driver, { durationMs: opts?.durationMs ?? 100 });
    const settleMs = opts?.settleMs ?? 20;
    if (settleMs > 0) {
        await driver.pause(settleMs);
    }
}

export async function tapCellWithScroll(
    driver: Browser,
    xpath: string,
    opts?: { maxSwipes?: number; settleMs?: number; swipeDurationMs?: number }
) {
    const maxSwipes = opts?.maxSwipes ?? 8;

    for (let i = 0; i <= maxSwipes; i++) {
        const candidates = await driver.$$(xpath);
        for (const el of candidates) {
            if (await el.isDisplayed()) {
                await el.click();
                return;
            }
        }

        if (i < maxSwipes) {
            await swipeUp(driver, {
                durationMs: opts?.swipeDurationMs ?? 100,
                settleMs: opts?.settleMs ?? 100,
            });
        }
    }

    throw new Error(`못 찾음: ${xpath}`);
}
