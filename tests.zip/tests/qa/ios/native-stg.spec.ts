import { test, expect } from '@appium/fixtures.ios';
import { safeClick, waitVisible } from '@tests/_shared/actions/ui';
import { getAndSwitchToWebviewIos } from '@tests/_shared/actions/webview';
import { smartTap } from '@tests/_shared/gestures/ios';

const TWD = 'com.sktelecom.miniTworld.ad.stg';
const logout = `//XCUIElementTypeStaticText[@name="로그아웃"]`;
const aiClose = `//XCUIElementTypeButton[@name="서비스 종료"]`;
const aiAssert = `//XCUIElementTypeOther[@name="메뉴선택"]`;
const aiBtn = `//XCUIElementTypeButton[@name="MY"]`;
const nudgeMessage = `//XCUIElementTypeApplication[@name="[STG] T world"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypeOther[9]/XCUIElementTypeOther/XCUIElementTypeLink`;

type LoginGate = 'alert' | 'continue' | 'id' | 'none';

async function detectLoginGate(
    driver: any,
    opts?: { timeoutMs?: number; intervalMs?: number }
): Promise<LoginGate> {
    const timeoutMs = opts?.timeoutMs ?? 8000;
    const intervalMs = opts?.intervalMs ?? 400;
    const continueBtn = `//XCUIElementTypeButton[@name="계속"]`;
    const idField = `//XCUIElementTypeTextField[@name="아이디 입력"]`;
    const iosAlert = `//XCUIElementTypeAlert`;
    const deadline = Date.now() + timeoutMs;

    while (Date.now() < deadline) {
        if (await driver.$(iosAlert).isDisplayed().catch(() => false)) return 'alert';
        if (await driver.$(continueBtn).isDisplayed().catch(() => false)) return 'continue';
        if (await driver.$(idField).isDisplayed().catch(() => false)) return 'id';
        await driver.pause(intervalMs);
    }
    return 'none';
}

async function openLoginFromMy(driver: any): Promise<{ selector: string; gate: LoginGate }> {
    const candidates = [
        `//XCUIElementTypeButton[@name="MY"]`,
        `(//XCUIElementTypeButton[@name="MY"])[2]`,
    ];

    for (const selector of candidates) {
        for (let attempt = 1; attempt <= 2; attempt++) {
            try {
                await smartTap(driver, selector, {
                    timeoutMs: 5000,
                    fallbackTapPct: { xPct: 0.5, yPct: 0.9 },
                    settleMs: 300,
                });
                const gate = await detectLoginGate(driver, { timeoutMs: 8000 });
                console.log(`[65] MY 탭 selector=${selector}, attempt=${attempt}, gate=${gate}`);
                if (gate !== 'none') return { selector, gate };
            } catch (e) {
                console.log(`[65] MY 탭 실패 selector=${selector}, attempt=${attempt}, error=${String(e)}`);
            }
        }
    }

    return { selector: '', gate: 'none' };
}

test.beforeEach(async ({ driver }) => {
    // 앱 상태를 초기화하기 위해 재실행
    try {
        await driver.terminateApp(TWD);
    } catch {}
    await driver.activateApp(TWD);
});

test(`Native iOS 65: 비로그인 AI Layer 접속`, async ({ driver }) => {
    const continueBtn = `//XCUIElementTypeButton[@name="계속"]`;
    const idField = `//XCUIElementTypeTextField[@name="아이디 입력"]`;
    const iosAlertContinue = `//XCUIElementTypeAlert//XCUIElementTypeButton[@name="계속"]`;

    console.log(`[65] start`);

    // 하단 메뉴 탭 진입
    await safeClick(driver, `//XCUIElementTypeOther[@name="메뉴 탭"]`);
    console.log(`[65] 메뉴 탭 진입 완료`);

    const logoutVisible = await driver.$(logout).isDisplayed().catch(() => false);
    console.log(`[65] logoutVisible=${logoutVisible}`);

    if (logoutVisible) {
        console.log(`[65] 분기: 로그인 상태 -> 로그아웃 진행`);
        await safeClick(driver, logout);
        await safeClick(driver, `//XCUIElementTypeStaticText[@name="예(Y)"]`);
        await safeClick(driver, `//XCUIElementTypeStaticText[@name="홈으로"]`);
        await driver.pause(2000);
    } else {
        console.log(`[65] 분기: 비로그인 상태 -> MY 바로 진입`);
    }

    const myResult = await openLoginFromMy(driver);
    console.log(`[65] MY 클릭 selector=${myResult.selector}, gate=${myResult.gate}`);
    if (myResult.gate === 'alert') {
        if (await driver.$(iosAlertContinue).isDisplayed().catch(() => false)) {
            await safeClick(driver, iosAlertContinue);
            console.log(`[65] iOS alert '계속' 클릭 처리`);
        } else {
            await driver.acceptAlert().catch(() => {});
            console.log(`[65] iOS alert accept 처리`);
        }

        const gateAfterAlert = await detectLoginGate(driver, { timeoutMs: 8000 });
        console.log(`[65] alert 처리 후 gate=${gateAfterAlert}`);
        if (gateAfterAlert === 'continue') {
            await safeClick(driver, continueBtn);
            await waitVisible(driver, idField, 5000);
            console.log(`[65] alert 이후 '계속' 처리`);
        } else {
            await waitVisible(driver, idField, 5000);
            console.log(`[65] alert 이후 아이디 입력 화면 진입`);
        }
    } else if (myResult.gate === 'continue') {
        await safeClick(driver, continueBtn);
        await waitVisible(driver, idField, 5000);
        console.log(`[65] '계속' 버튼 처리 후 로그인 화면 진입`);
    } else if (myResult.gate === 'id') {
        console.log(`[65] 아이디 입력 화면 직접 진입 상태`);
    } else {
        throw new Error(`[65] 로그인 진입 실패: MY 클릭 후 게이트 미노출`);
    }

    // 로그인 화면 전환 대기
    await driver.pause(1000);

    // 로그인 정보 입력
    // 1. 아이디 입력 칸을 먼저 찾고 아이디 및 비번 입력 시도
    // 2. 없으면 '다른 아이디로 로그인' 클릭 이후 다시 아이디 및 비번 입력 재시도
    const idInput = await (async () => {
        try {
            console.log(`[65] 아이디 입력칸 직접 탐색`);
            return await waitVisible(driver, idField, 3000);
        } catch {
            console.log(`[65] 다른 아이디로 로그인 분기`);
            await safeClick(driver, `//XCUIElementTypeButton[@name="다른 아이디로 로그인"]`);
            return await waitVisible(driver, idField, 5000);
        }
    })();

    await idInput.click();
    await idInput.addValue(`pleasep@naver.com`);
    await driver.pause(1000);

    const pwInput = await waitVisible(driver, `//XCUIElementTypeSecureTextField[@name="비밀번호 입력"]`, 10000);
    await pwInput.click();
    await pwInput.addValue(`!test1234`);

    await safeClick(driver, `//XCUIElementTypeButton[@name="로그인"]`);
    await driver.pause(5000);
    
    expect(await waitVisible(driver, aiAssert, 5000)).toBeTruthy();
    console.log(`[65] AI Layer 노출 검증 성공`);
    
    await safeClick(driver, aiClose);
    await driver.pause(3000);
    console.log(`[65] end`);
});

test(`Native iOS 66: 로그인 상태에서 AI Layer 접속`, async ({ driver }) => {
    await smartTap(driver, aiBtn, {fallbackTapPct: {xPct: 0.5, yPct: 0.9}});
    await driver.pause(5000);
    expect(await waitVisible(driver, aiAssert, 5000)).toBeTruthy();

    await safeClick(driver, aiClose);
    await driver.pause(1000);
});

/*
test(`Native iOS 67: 간편로그인 상태에서 AI Layer 접속`, async ({ driver }) => {
    await safeClick(driver, `//XCUIElementTypeOther[@name="메뉴 탭"]`);

    if (await driver.$(logout).isDisplayed().catch(() => false)) {
        await safeClick(driver, logout);
        await safeClick(driver, `//XCUIElementTypeStaticText[@name="예(Y)"]`);
        await safeClick(driver, `//XCUIElementTypeStaticText[@name="홈으로"]`);
        await driver.pause(1000);
        await smartTap(driver, aiBtn, {fallbackTapPct: {xPct: 0.5, yPct: 0.9}});
    }
    await driver.pause(3000);
    let alertText = '';
    try {
        alertText = await driver.getAlertText();
    } catch {
        alertText = '';
    }
    if (alertText) await driver.acceptAlert();
    await driver.pause(1000);
    await safeClick(driver, `//XCUIElementTypeButton[@name="본인 확인된 T ID pleasep@naver.com 010-8832-0456 로 로그인"]`);
    await driver.pause(5000);

    expect(await waitVisible(driver, aiAssert, 5000)).toBeTruthy();

    await safeClick(driver, aiClose);
    await driver.pause(1000);
});
*/

test(`Native iOS 70: TWD / TDS 각 메인에서 AI Layer 진입`, async ({ driver, }) => {
    await safeClick(driver, `//XCUIElementTypeOther[@name="홈 탭"]`);
    await smartTap(driver, aiBtn, {fallbackTapPct: {xPct: 0.5, yPct: 0.9}});
    await driver.pause(5000);
    
    const twdAssert = await waitVisible(driver, aiAssert, 5000);
    const twdValue = String((await twdAssert.getAttribute(`value`)) ?? '').trim();
    expect(twdValue).toBe('전체');

    await safeClick(driver, aiClose);
    await driver.pause(3000);

    await safeClick(driver, `//XCUIElementTypeOther[@name="T 다이렉트샵 탭"]`);
    await smartTap(driver, aiBtn, {fallbackTapPct: {xPct: 0.5, yPct: 0.9}});
    await driver.pause(5000);
    
    const tdsAssert = await waitVisible(driver, aiAssert, 5000);
    const tdsValue = String((await tdsAssert.getAttribute(`value`)) ?? '').trim();
    expect(tdsValue).toBe('T 다이렉트샵');

    await safeClick(driver, aiClose);
    await driver.pause(1000);
});

test(`Native iOS 71: 한영 전환하며 바텀 구성 및 버튼확인`, async ({ driver }) => {
    await safeClick(driver, `//XCUIElementTypeOther[@name="메뉴 탭"]`);
    await driver.pause(1000);
    const ENG = `//XCUIElementTypeStaticText[@name="English!"]`;
    await safeClick(driver, ENG);
    expect(await waitVisible(driver, `//XCUIElementTypeButton[@name="MY"]`, 5000)).toBeTruthy();

    await safeClick(driver, `//XCUIElementTypeOther[@name="MENU 탭"]`);
    await driver.pause(1000);
    const KOR = `(//XCUIElementTypeLink[@name="국문 사이트 이동"])[2]`;
    await safeClick(driver, KOR);
    expect(await waitVisible(driver, aiBtn, 5000)).toBeTruthy();
});


test(`Native iOS 77: 정회원 로그인 후 TWD/TDS 각 메인에서 넛징 선택`, async ({ driver }) => {
    await safeClick(driver, `//XCUIElementTypeButton[@name="nudge"]`);

    // 웹뷰 전환
    await getAndSwitchToWebviewIos(driver);
    await waitVisible(driver, `//button[normalize-space(.)='nudge 초기화']`);

    await driver.execute(() => {
        // 웹뷰 안에서 'nudge 초기화' 버튼을 찾는다.
        const btn = [...document.querySelectorAll('button')].find(
            (el) => (el.textContent || '').trim() === 'nudge 초기화'
        ) as HTMLElement | undefined;

        // btn.click()을 바로 실행하면 execute가 오래 붙잡혀 timeout 발생
        // 그래서 "지금 함수가 끝난 직후" 클릭하도록 예약
        // (setTimeout(..., 0) = 지연 없이 다음 순서에 클릭 실행)
        if (btn) window.setTimeout(() => btn.click(), 0);
    });
    await driver.pause(500);

    // 네이티브 전환
    await driver.switchContext('NATIVE_APP');
    await safeClick(driver, `//XCUIElementTypeButton[@name="확인"]`);

    // TWD 넛징 확인
    await driver.terminateApp(TWD);
    await driver.activateApp(TWD);

    await safeClick(driver, nudgeMessage);
    await driver.pause(5000);
    const twdAssert = await waitVisible(driver, aiAssert, 5000);
    const twdValue = String((await twdAssert.getAttribute(`value`)) ?? '').trim();
    expect(twdValue).toBe('전체');

    await safeClick(driver, aiClose);
    await driver.pause(1000);    
    
    // TDS 넛징 확인
    await safeClick(driver, `//XCUIElementTypeOther[@name="T 다이렉트샵 탭"]`);
    await safeClick(driver, nudgeMessage);
    await driver.pause(5000);
    const tdsAssert = await waitVisible(driver, aiAssert, 5000);
    const tdsValue = String((await tdsAssert.getAttribute(`value`)) ?? '').trim();
    expect(tdsValue).toBe('T 다이렉트샵');
});

test(`Native iOS 78: 넛징 노출 후 x영역 터치`, async ({ driver }) => {
    await safeClick(driver, `//XCUIElementTypeButton[@name="nudge"]`);

    // 웹뷰 전환
    await getAndSwitchToWebviewIos(driver);
    await waitVisible(driver, `//button[normalize-space(.)='nudge 초기화']`);

    await driver.execute(() => {
        // 웹뷰 안에서 'nudge 초기화' 버튼을 찾는다.
        const btn = [...document.querySelectorAll('button')].find(
            (el) => (el.textContent || '').trim() === 'nudge 초기화'
        ) as HTMLElement | undefined;

        // btn.click()을 바로 실행하면 execute가 오래 붙잡혀 timeout 발생
        // 그래서 "지금 함수가 끝난 직후" 클릭하도록 예약
        // (setTimeout(..., 0) = 지연 없이 다음 순서에 클릭 실행)
        if (btn) window.setTimeout(() => btn.click(), 0);
    });
    await driver.pause(500);

    // 네이티브 전환
    await driver.switchContext('NATIVE_APP');
    await safeClick(driver, `//XCUIElementTypeButton[@name="확인"]`);

    await driver.terminateApp(TWD);
    await driver.activateApp(TWD);
    await driver.pause(1000);

    // 넛징 메세지 x 클릭
    await safeClick(driver, `(//XCUIElementTypeButton[@name="닫기"])[2]`);
    // 넛징 메세지 미노출 확인
    const visible = await driver.$(nudgeMessage).isDisplayed().catch(() => false);
    expect(visible).toBe(false);
});

test(`Native iOS 79: 같은 계정으로 앱 재실행`, async ({ driver }) => {
    // TWD 넛징 메세지 미노출 확인
    const visible = await driver.$(nudgeMessage).isDisplayed().catch(() => false);
    expect(visible).toBe(false);
});

test(`Native iOS 80: TWD / TDS 각 채널에 맞는 넛징 메세지 노출 확인`, async ({ driver }) => {
    const twdMsg = [
        '"AI 추천이 발견했어요! 내게 필요한 것 모아 보기"의 썸네일 이미지', '"T 월드·T 다이렉트샵·T 멤버십에서 AI가 필요한 정보만 모았어요"의 썸네일 이미지', 
        '"혹시 변경해야 할 정보는 없는지 AI T 서비스로 체크해 볼까요?"의 썸네일 이미지', '"고객센터에 문의했던 내용 AI T 서비스가 해결해 드려요"의 썸네일 이미지', 
        '"구매부터 요금제 관리, 혜택까지 AI가 나의 T 서비스를 밀착 관리"의 썸네일 이미지', '"T 서비스 1000% 활용 방법! 나에게 맞는 정보만 모아 드려요"의 썸네일 이미지', 
        '"시간 절약을 위한 맞춤 솔루션 AI가 필요한 기능을 찾아왔어요"의 썸네일 이미지', '"꼭 필요한 순간에 맞춤 제안 시간·상황에 맞춰 알려 드려요"의 썸네일 이미지', 
        '"T의 멈추지 않는 추천 매일이 새로워지는 탐색 시작!"의 썸네일 이미지',
    ];
    const tdsMsg = [
        '"헌 집 줄게 새집 다오! 쓰던 폰 보상받고 새 폰 주문하기!"의 썸네일 이미지',
    ];

    await safeClick(driver, `//XCUIElementTypeButton[@name="nudge"]`);

    // 웹뷰 전환
    await getAndSwitchToWebviewIos(driver);
    await waitVisible(driver, `//button[normalize-space(.)='nudge 초기화']`);

    await driver.execute(() => {
        // 웹뷰 안에서 'nudge 초기화' 버튼을 찾는다.
        const btn = [...document.querySelectorAll('button')].find(
            (el) => (el.textContent || '').trim() === 'nudge 초기화'
        ) as HTMLElement | undefined;

        // btn.click()을 바로 실행하면 execute가 오래 붙잡혀 timeout 발생
        // 그래서 "지금 함수가 끝난 직후" 클릭하도록 예약
        // (setTimeout(..., 0) = 지연 없이 다음 순서에 클릭 실행)
        if (btn) window.setTimeout(() => btn.click(), 0);
    });
    await driver.pause(500);

    // 네이티브 전환
    await driver.switchContext('NATIVE_APP');
    await safeClick(driver, `//XCUIElementTypeButton[@name="확인"]`);

    await driver.terminateApp(TWD);
    await driver.activateApp(TWD);
    await driver.pause(1000);

    // 메인(TWD) 진입
    // twdMsg가 넛징 메세지의 name값을 포함하는지 검증
    const twdNudgeName = String((await (await waitVisible(driver, nudgeMessage, 5000)).getAttribute(`name`)) ?? '').trim();
    expect(twdMsg).toContain(twdNudgeName);

    // TDS 진입
    // tdsMsg가 넛징 메세지의 name값을 포함하는지 검증
    await safeClick(driver, `//XCUIElementTypeOther[@name="T 다이렉트샵 탭"]`);
    const tdsNudgeName = String((await (await waitVisible(driver, nudgeMessage, 5000)).getAttribute(`name`)) ?? '').trim();
    expect(tdsMsg).toContain(tdsNudgeName);
})
