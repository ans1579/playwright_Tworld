import { test, expect } from '@appium/fixtures.ios';
import { smartTap } from '@tests/_shared/gestures/ios';
import { tapCellWithScroll } from '@tests/_shared/actions/scroll';
import { isVisible, safeClick } from '@tests/_shared/actions/ui';

// iOS 설정 앱으로 세션 시작
const SETTINGS_BUNDLE_ID = `com.apple.Preferences`;
test.use({ bundleId: SETTINGS_BUNDLE_ID });

// 대상 앱 번들 아이디(설정에서 앱 찾을 때 사용)
const TWD = `com.sktelecom.miniTworld.ad.stg`;

test(`N87: iOS 위치권한 끄고 AI Layer 진입`, async ({ driver }) => {
    
    await test.step(`0. 위치 권한 해제`, async () => {
        // 설정 앱 진입
        try {
            await driver.terminateApp(SETTINGS_BUNDLE_ID);
        } catch {}
        await driver.activateApp(SETTINGS_BUNDLE_ID);

        // 설정 > 앱 > [STG] T world 이동
        await tapCellWithScroll(driver, '//XCUIElementTypeButton[@name="com.apple.settings.apps"]');
        await tapCellWithScroll(driver, `//XCUIElementTypeStaticText[@name="[STG] T world"]`);
        await driver.pause(1000);

        // 위치 권한을 "다음번에 다시 묻기 또는 내가 공유할 때"로 변경
        const location = await driver.$(`//XCUIElementTypeStaticText[@name="위치"]`);
        await location.click();
        await driver.pause(1000);
        
        const nextQuestion= await driver.$('//XCUIElementTypeCell[@name="다음번에 묻기 또는 내가 공유할 때"]');
        await nextQuestion.click();
        await driver.pause(1000);
    });

    await test.step(`1. 앱 실행 및 AI Layer 클릭`, async () => {
        try {
            await driver.terminateApp(TWD);
        } catch {}
        await driver.activateApp(TWD);
        await driver.pause(2000);
        
        await smartTap(driver, `//XCUIElementTypeButton[@name="MY"]`, {
            timeoutMs: 3000,
            fallbackTapPct: { xPct: 0.5, yPct: 0.90 },
        })
    });

    await test.step(`2. AI Layer 진입 -> `, async () => {
        await driver.pause(2000);
        const shown = await isVisible(driver, `//XCUIElementTypeAlert[@name="‘[STG] T world’ 앱이 사용자의 위치를 사용하도록 허용하겠습니까?"]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeScrollView[1]/XCUIElementTypeOther[1]`, 10000);
        expect(shown).toBe(true);
        
        await safeClick(driver, `//XCUIElementTypeButton[@name="앱을 사용하는 동안 허용"]`, {timeoutMs: 10000});
    });
})
